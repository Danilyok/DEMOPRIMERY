﻿using System;
using System.ComponentModel;
using System.Data;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Input;
using Variant3.Model;
using Variant3.View;
using System.Data.SqlClient;
using System.Runtime.CompilerServices;
using System.Security.Cryptography;
using System.Text;

namespace Variant3.ViewModel
{
    public class RegViewModel : INotifyPropertyChanged
    {
        private string _имя;
        private string _телефон;
        private string _адрес;
        private string _логин;
        private string _пароль;

        public string Имя
        {
            get => _имя;
            set => SetProperty(ref _имя, value);
        }

        public string Телефон
        {
            get => _телефон;
            set => SetProperty(ref _телефон, value);
        }

        public string Адрес
        {
            get => _адрес;
            set => SetProperty(ref _адрес, value);
        }

        public string Логин
        {
            get => _логин;
            set => SetProperty(ref _логин, value);
        }

        public string Пароль
        {
            get => _пароль;
            set => SetProperty(ref _пароль, value);
        }

        public ICommand RegisterCommand { get; }

        public RegViewModel()
        {
            RegisterCommand = new RelayCommand1(OnRegister);
        }

        private void OnRegister()
        {
            string connectionString = @"Data Source=LAPTOP-VF6RUNDD; DataBase=Var3; Integrated Security=True; Trusted_Connection=true; MultipleActiveResultSets=true; TrustServerCertificate=true; encrypt=false;"; // Замените на вашу строку подключения

            using (var connection = new SqlConnection(connectionString))
            {
                connection.Open();

                string query = "INSERT INTO Клиент (Имя, Телефон, Адрес, Логин, Пароль) VALUES (@Имя, @Телефон, @Адрес, @Логин, @Пароль)";

                using (var command = new SqlCommand(query, connection))
                {
                    command.Parameters.AddWithValue("@Имя", Имя);
                    command.Parameters.AddWithValue("@Телефон", Телефон);
                    command.Parameters.AddWithValue("@Адрес", Адрес);
                    command.Parameters.AddWithValue("@Логин", Логин);
                    command.Parameters.AddWithValue("@Пароль", HashPassword(Пароль)); // Хеширование пароля

                    try
                    {
                        command.ExecuteNonQuery();
                        MessageBox.Show("Регистрация успешна!");
                    }
                    catch (SqlException ex)
                    {
                        MessageBox.Show("Ошибка при регистрации: " + ex.Message);
                    }
                }
            }
        }

        private string HashPassword(string password)
        {
            using (var sha256 = SHA256.Create())
            {
                var bytes = sha256.ComputeHash(Encoding.UTF8.GetBytes(password));
                return Convert.ToBase64String(bytes);
            }
        }

        public event PropertyChangedEventHandler PropertyChanged;

        protected virtual void OnPropertyChanged([CallerMemberName] string propertyName = null)
        {
            PropertyChanged?.Invoke(this, new PropertyChangedEventArgs(propertyName));
        }

        protected bool SetProperty<T>(ref T field, T value, [CallerMemberName] string propertyName = null)
        {
            if (Equals(field, value)) return false;
            field = value;
            OnPropertyChanged(propertyName);
            return true;
        }
    }

    public class RelayCommand1 : ICommand
    {
        private readonly Action _execute;
        private readonly Func<bool> _canExecute;

        public RelayCommand1(Action execute, Func<bool> canExecute = null)
        {
            _execute = execute ?? throw new ArgumentNullException(nameof(execute));
            _canExecute = canExecute;
        }

        public bool CanExecute(object parameter) => _canExecute?.Invoke() ?? true;

        public void Execute(object parameter) => _execute();

        public event EventHandler CanExecuteChanged
        {
            add => CommandManager.RequerySuggested += value;
            remove => CommandManager.RequerySuggested -= value;
        }
    }
}
