﻿using System.Windows.Controls;
using Variant3.Model;
using Variant3.ViewModel;

namespace Variant3.View
{
    public partial class Shop : UserControl
    {
        public Shop()
        {
            InitializeComponent();
            this.DataContext = new ShopViewModel(this);
        }
    }
}
